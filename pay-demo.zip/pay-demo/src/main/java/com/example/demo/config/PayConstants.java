package com.example.demo.config;

/**
 * @Author:caoxiang
 * @Description:
 * @Date: Create in 21:37 2018/4/13
 * @Modified By;
 */
public class PayConstants {

    public static final String EQU = "=";

    public static final String AND = "&";
}